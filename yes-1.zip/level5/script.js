var aud = document.getElementById("Audio");
aud.onended = function() {
    alert("The audio has ended");
};