function next() {
	document.location.href = '/level3/level3.html';
}
function tönt() {
	document.location.href = '/level/level.html';
}