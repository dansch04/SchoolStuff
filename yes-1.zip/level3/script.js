var Calls = 0;

function func() {
	Calls++;
	alert("tryck på den andra bilden");
	if (Calls >= 4){
	document.location.href = '/level4/level4.html';
	}
}
