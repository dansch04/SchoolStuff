var Calls = 0;

function fadeout() {
  document.getElementById('fadeout').style.opacity = '0';
  document.getElementById('fadein').style.opacity = '0';
  document.getElementById('button2').style.opacity = '0';
  document.getElementById('button3').style.opacity = '1';
	document.getElementById('button3').disabled = false;
	document.getElementById('button2').disabled = true;
}
function fadein() {
  Calls++;
	document.getElementById('button2').disabled = false;
	document.getElementById('button3').disabled = true;
  document.getElementById('fadeout').style.opacity = '1';
  document.getElementById('fadein').style.opacity = '1';
  document.getElementById('button3').style.opacity = '0';
  document.getElementById('button2').style.opacity = '1';
  if (Calls >= 3) {
      next();
  }
}

function next() {
  document.getElementById('button4').disabled = false;
  document.getElementById('fadeout').style.opacity = '0';
  document.getElementById('fadein').style.opacity = '0';
  document.getElementById('button2').style.opacity = '0';
  document.getElementById('button3').style.opacity = '0';
  document.getElementById('button4').style.opacity = '1';
}