function func() {
	document.location.href = '/level5/level5.html';
}